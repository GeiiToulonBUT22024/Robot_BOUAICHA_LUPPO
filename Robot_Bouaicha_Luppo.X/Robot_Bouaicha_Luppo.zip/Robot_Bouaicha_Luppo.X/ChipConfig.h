/* 
 * File:   ChipConfig.h
 */

#ifndef CHIPCONFIG_H
#define	CHIPCONFIG_H

void InitOscillator();

#endif	/* CHIPCONFIG_H */
